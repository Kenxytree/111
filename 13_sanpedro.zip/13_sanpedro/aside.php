<aside>
    Recursos complementarios.
    <br><br><iframe width="200" height="200" src="https://www.youtube.com/embed/oSzzVdxbu5Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    <br><br><iframe width="200" height="200" src="https://www.youtube.com/embed/GxdtcKn0-Mw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</aside>
