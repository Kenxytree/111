<footer>        
    <div>©2020 - www.sanpedrohuancayo.com. Todos los derechos reservados. </div>
    <div>NUESTRO CAMPUS</div>
    <div>Dirección: Calle Real 892 Huancayo</div>
    <div>Telefonos: (064) 235689 - (064) 235612</div>        
</footer>