<!doctype html>
<html lang="en">

<?php require_once('head.php'); ?>

<body>
    

<?php
    require_once('header.php');
    require_once('nav.php');
?>


<main>
    <article>    
        <H1>Cronograma de matricula</H1>
        <table>
            <tr>
                <th>Lunes</th>
                <th>Martes</th>
                <th>Miercoles</th>
            </tr>
            <tr>
                <td>Inicial</td>
                <td>Primarias</td>
                <td>Secundaria</td>
            </tr>
        </table>       
    </article>
    <article>
        <H1>Importancia de estar vacunados</H1>
        <img src="img/vacunación.jpg" alt="vacunados" width="300" height="300">
        <img src="img/vacunación.png" alt="vacunados" width="300" height="300">
    </article>
</main>

<?php
    require_once('aside.php');
    require_once('footer.php');
?>


</body>
</html>