<!doctype html>
<html lang="en">

<?php require_once('head.php'); ?>

<body>

<?php
    require_once('header.php');
    require_once('nav.php');
?>

<main>    
    <article>  
        <H1>Servicios que ofrecemos</H1>
        <table>
            <tr>
                <th></th>
                <th>Lunes-viernes</th>
                <th>Sabado</th>
                <th>Domingo</th>
                
            </tr>
            <tr>
                <th>Actividades academicas</th>
                <td>x</td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <th>Actividades extracurriculares</th>
                <td>x</td>
                <td>x</td>
                <td></td>
            </tr>
            <tr>
                <th>Campeonatos</th>
                <td></td>
                <td></td>
                <td>x</td>
            </tr>
        </table>     
    </article>   
    <article>
        <H1>Importancia de una educación integral</H1>
        <img src="img/actividades academicas.jpg" alt="vacunados" width="300" height="300">
        <img src="img/actividades extracurriculares.jpg" alt="vacunados" width="300" height="300">
        <img src="img/campeonatos.jpg" alt="vacunados" width="300" height="300">   
    </article>
</main>

<?php
    require_once('aside.php');
    require_once('footer.php');
?>


</body>
</html>