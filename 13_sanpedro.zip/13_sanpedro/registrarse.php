<!DOCTYPE HTML>  
<html lang="en">

<?php require_once('head.php'); ?>

<body>

<?php
    require_once('header.php');
    require_once('nav.php');
?>

<?php

error_reporting(E_ERROR); // para descativar los warnings(advertencias)

require_once('Modelo/Usuario.php');
$usuario = new Usuario();

$datosFormularioValidos =false;
$mensajesErrores= array();


if ($_SERVER["REQUEST_METHOD"] == "POST") {  

  $usuario->setDNI($_POST["DNI"]);
  $usuario->setNombre($_POST["nombre"]);
  $usuario->setClave($_POST["clave"]);
  $usuario->setClaveRepetir($_POST["claveRepetir"]);
  $usuario->setRol($_POST["rol"]);
  $usuario->setCorreoElectronico($_POST["correoElectronico"]);

  //$usuario->evaluarParClaves();

 


  $mensajesErrores=$usuario->mensajesErrores;

  if(count($mensajesErrores)>0){
    $datosFormularioValidos=false;

  }else{
    $datosFormularioValidos=true;
    // insertar en la base de datos 
  }  

}


?>


<main>

<?php
  if(!$datosFormularioValidos){
?>

    <h2>Formulario de registro de usuario</h2>

    <p><span class="errorDatosFormulario">* Campo requerido</span></p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" novalidate>
    
    <p class="errorDatosFormulario"><?php echo $mensajesErrores["evaluarParClaves"];?></p>  
    <br><br>
    
    DNI: <input class="form-control"  type="text" id="DNI" name="DNI" autocomplete="off"  required value="<?php echo $usuario->getDNI();?>">
    <span class="errorDatosFormulario">* <?php echo $mensajesErrores["DNI"];?></span>
    <br><br>
   
    Nombre: <input class="form-control"  type="text" id="nombre" name="nombre" autocomplete="off"  required value="<?php echo $usuario->getNombre();?>">
    <span class="errorDatosFormulario">* <?php echo $mensajesErrores["nombre"];?></span>
    <br><br>
    
    Clave: <input class="form-control"  type="password" id="clave" name="clave" autocomplete="off"  required autocomplete="off">
    <span class="errorDatosFormulario">* <?php echo $mensajesErrores["clave"];?></span>
    <br><br>
    
    Repetir clave: <input class="form-control" type="password" id="claveRepetir" name="claveRepetir" required autocomplete="off">
    <span class="errorDatosFormulario">*<?php echo $mensajesErrores["claveRepetir"];?></span>  
    <br><br>
     
    Rol: 
    <select name="rol" id="rol">
    | <?php $op= ("invitado" == $usuario->getRol()) ? " SELECTED" : ""; ?>
      <option <?php echo $op; ?> value="invitado">invitado</option>
      <?php $op= ("cliente" == $usuario->getRol()) ? " SELECTED" : ""; ?>
      <option <?php echo $op; ?> value="cliente">cliente</option>
    </select>  
    <br><br>

    Email: <input  class="form-control" type="email" name="correoElectronico" id="correoElectronico" autocomplete="off"  required size="50" value="<?php echo $usuario->getCorreoElectronico();?>">
    <span class="errorDatosFormulario">* <?php echo $mensajesErrores["correoElectronico"];?></span>
    <br><br>

    

    <button type="submit">Registrarse</button>
    </form>

<?php
  }else{
    echo "<br>Los datos del formulario fueron enviados al servidor";
  }
?>


</main>


<?php
    require_once('aside.php');
    require_once('footer.php');
?>



</body>
</html>