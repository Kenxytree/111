<head>
        <meta charset="utf-8" />
        <title>Colegio San Pedro</title>      
        <link  rel="icon"   href="img/logotipo.png" type="image/png"/>
        <meta name="application-name" content="sitio web de colegio san pedro huancayo">
        <meta name="author" content="Walter Rivera Segura">
        <meta name="description" content="informacion acerce del colegio san pedro huancayo">
        <meta name="generator" content="VS CODE">
        <meta name="keywords" content="colegio san pedro huancayo, matricula, costos de pension">

  	<link rel="stylesheet" type="text/css" href="css/estilos.css"/>
</head>