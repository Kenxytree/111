<!doctype html>
<html lang="en">

<?php require_once('head.php'); ?>

<body>

<?php
    require_once('header.php');
    require_once('nav.php');
?>


<main>
    <h1>Puedes ubicarnos segun mapa.</h1>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.6854577683093!2d-75.21192738456644!3d-12.065149545529199!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x910e964926442411%3A0xcd4ee6c893bc4905!2sJr%20Ayacucho%20230%2C%20Huancayo%2012001!5e0!3m2!1ses-419!2spe!4v1645297151857!5m2!1ses-419!2spe" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</main>

<?php
    require_once('aside.php');
    require_once('footer.php');
?>

</body>
</html>





