<nav>    
    <ul>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="servicios.php">servicios</a></li>        
        <li><a href="actividades.php">Actividades</a></li>      
        <li><a href="ubicacion.php">Ubicacion</a></li>
        <li><a href="calcular_matricula_pension.php">Calcular costo de matrícula y pensión</a></li>
        <li><a href="registrarse.php">Registrarse</a></li>
        <li><a href="iniciar_sesion.php">Iniciar sesión</a></li>
    </ul>
</nav>