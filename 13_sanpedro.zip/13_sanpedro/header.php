<header>    
        <img src="img/logotipo.png" alt="logotipo" width="100" height="100">
        <audio src="sound/fondo.mp3" preload="auto" loop controls></audio>        
        <div>
            Colegio San Pedro, innovando en educación.
        </div>       
</header>