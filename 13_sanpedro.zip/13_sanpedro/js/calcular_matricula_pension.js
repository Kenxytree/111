function Calcular() {    
  
    let op1 = document.getElementById("chkColegio").checked;    
    let op2 = document.getElementById("chkAcademia").checked;
    
    let costoMatricula=0;
    if(op1){
        costoMatricula+=500;
    }
    if(op2){
        costoMatricula+=300;
    }   


    let turnos=document.getElementsByName("rdTurnos");
    let turno;

    for(i=0; i<turnos.length; i++){
        if(turnos[i].checked){
            turno=turnos[i].value;            
            break;        
        }
    }

    let costoPension=0;
    switch(turno){
        case "rdTurnoManana":
            costoPension=costoMatricula*0.7;
            break;
        case "rdTurnoTarde":
            costoPension=costoMatricula*0.6;
            break;         
    }
   
    document.getElementById("divRespuesta").innerHTML="Costo matricula: S/ "+costoMatricula+", costo pension: S/ "+costoPension;
   
  }

  window.onload = function() {
    document.getElementById("btnCalcular").onclick = Calcular;
  }