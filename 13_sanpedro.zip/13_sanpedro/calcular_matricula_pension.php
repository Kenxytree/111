<!doctype html>
<html lang="en">

<?php require_once('head.php'); ?>

<body>

<?php
    require_once('header.php');
    require_once('nav.php');
?>


 
<main>
    <h4>Selecciona tus opciones para matricula:</h4>
    <input name="chkColegio" id="chkColegio" type="checkbox" />Colegio
    <br><input name="chkAcademia" id="chkAcademia" type="checkbox" />Academia    
  
    <h4>Selecciona turno a matricular:</h4>
    <input type= "radio" name="rdTurnos" id="rdTurnoManana" value="rdTurnoManana" checked>Turno mañana
    <br>
    <input type= "radio" name="rdTurnos" id="rdTurnoTarde" value="rdTurnoTarde">Turno tarde            
    <br>
    <br>
    <button type="button" name="btnCalcular" id="btnCalcular">Calcular</button>
    
    <br>
    <br>
    <div id="divRespuesta">
    </div>
</main>

<?php
    require_once('aside.php');
    require_once('footer.php');
?>



<script src="js/calcular_matricula_pension.js"></script>

</body>
</html>