<!doctype html>
<html lang="en">

<?php require_once('head.php'); ?>

<body>

<?php
    require_once('header.php');
    require_once('nav.php');
?>



<?php    

 

// definir variables y ponerlas en valores vacíos
$nombreError =$claveError =$inicioSesionError="";
$nombre = $clave = "";



if ($_SERVER["REQUEST_METHOD"] == "POST") {  

  $datosValidos=true;


  if (empty($_POST["nombre"])) {
    $nombreError = "El nombre de usuario es obligatorio";
    $datosValidos=false;
  } else {
    $nombre = test_input($_POST["nombre"]);    
  }

  if (empty($_POST["clave"])) {
    $claveError = "La clave es obligatoria";
    $datosValidos=false;
  } else{
    $clave = test_input($_POST["clave"]);    
    } 
  

  if($datosValidos){

    /* procesamos los datos, su todo bien lo redirigimos a la pagina de inicio  */ 
  
    echo "Datos validados";
    exit;

  
  }
  

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>


<main>

    <h2>Formulario de Inicio de sesion</h2>

    <p><span class="errorDatosFormulario">* Campo requerido</span></p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 

      Nombre de usuario: <input class="form-control" type="text" name="nombre" id="nombre" autocomplete="off"  required>
      <span class="errorDatosFormulario">* <?php echo $nombreError;?></span>
      <br><br>
      Clave: <input  class="form-control" type="password" name="clave" id="clave" autocomplete="off"  required>
      <span class="errorDatosFormulario">* <?php echo $claveError;?></span>
      <br><br>
      <span class="errorDatosFormulario"><?php echo $inicioSesionError;?></span>
      <br><br>   
      <button type="submit">Iniciar sesión</button>
    </form>

</main>

<?php
    require_once('aside.php');
    require_once('footer.php');
?>



</body>

</html>