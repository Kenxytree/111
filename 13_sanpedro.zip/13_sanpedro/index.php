<!doctype html>
<html lang="en">
<?php require_once('head.php'); ?>
<body>

<?php
    require_once('header.php');
    require_once('nav.php');
?>

<main>
    <article>    
        <H1>Vacunarán a 10,500 docentes de zonas rurales de la región Junín</H1>
        <p>En un ambiente festivo, docentes de zonas rurales de la región Junín son vacunados contra la covid-19, de acuerdo con la lista de 10,500 beneficiarios emitida por el Ministerio de Educación previa validación de la Dirección Regional de Educación.
        </p>
        <p>La inoculación de los maestros con la primera dosis de la vacuna Pfizer fue supervisada por el gobernador regional de Junín, Fernando Orihuela Rojas, quien precisó que la inmunización, en todas las provincias, se extenderá hasta el 8 de julio, según el calendario establecido para los docentes que anhelan volver a las aulas.</p>
    </article>
    <hr>
    <article>
        <H1>No garantizan retorno a clases presenciales</H1>
        <p>No cumple con su palabra. Pese a que el presidente Pedro Castillo anunció el año pasado el retorno a las clases escolares presenciales para marzo de este año, el Ministerio de Educación (Minedu) informó ayer que el regreso a las aulas no se dará de forma total.</p> 
        <p>A menos de seis semanas de la fecha estimada para el comienzo de las clases, <strong>el Minedu recién dio a conocer que se tienen previstas tres modalidades de estudio: <em>presencial, semipresencial y a distancia.</em></strong> La herramienta creada para la educación virtual Aprendo en Casa, y que se transmite por televisión, se seguirá utilizando en 2022.</p>
    </article>
</main>        

<?php
    require_once('aside.php');
    require_once('footer.php');
?>

</body>
</html>